/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidtracing;

import java.time.LocalDate;
import java.util.Comparator;

/**
 *
 * @author Zac
 */
public class DateDiagnosedComparator implements Comparator<User> {

    @Override
    public int compare(User o1, User o2) {
      
       if(o1.date_diagnosis.compareTo(o2.date_diagnosis) > 0){
           return -1;
       }
       else if(o1.date_diagnosis.compareTo(o2.date_diagnosis) < 0){
           return 1;
       }
        else{
        return 0;
        }
    }
    
}
