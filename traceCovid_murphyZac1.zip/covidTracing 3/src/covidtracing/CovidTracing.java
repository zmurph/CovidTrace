/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package covidtracing;
import bridges.base.GraphAdjListSimple;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import bridges.base.SLelement;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import java.time.LocalDate;

/**
 *
 * @author Zac
 */
public class CovidTracing {
//ArrayList<> cars = new List<>();
   List<String> obj = new ArrayList<>();
   private static final String FILE_NAME = "users.csv";        
   private static final String fileContact = "contacts.csv";
   public static ArrayList<User> user = new ArrayList<>();
   /***
    * main method where all other 
    * methods are actually ran
    * @param args 
    */
    public static void main(String[] args) {
       
       //Test if the user list is sorted 
       //loadFromFile();
       //System.out.println(user);
        
       //Test if the file can be loaded 
       loadFromFile();
       loadContact(0);
       //Test if the load contact works
       //User user2 = new User();
       ArrayList<User> infected = new ArrayList<>();
       User user2 = new User();
       for(int i = 0; i < user.size(); i++){
           user2 = user.get(i);
           if(user2.isInfected()){
                infected.add(user2);
           }
       }
       DateDiagnosedComparator dateDiagCompare = new DateDiagnosedComparator();
       Collections.sort(infected, dateDiagCompare);
       int graphId = 3;
       
       createBridgesGraph(user, graphId);

    }
    /***
     * load data from the user list that contains
     * all of the user information
     * @return 
     */
    public static ArrayList<User> loadFromFile(){
        //ArrayList<User> user = new ArrayList<>();
            User user1 = new User();
            String line;
            String[] tokens;
            try(Scanner fileInput = new Scanner(new File(FILE_NAME))){
                fileInput.nextLine();
                while(fileInput.hasNext())
                {
                    line = fileInput.nextLine();
                    tokens = line.split(",");
                    user1 = new User();
                    user1.setUser_id(Integer.parseInt(tokens[0]));
                    user1.setFirst_name(tokens[1]);
                    user1.setLast_name(tokens[2]);
                    user1.setGender(tokens[3]);
                    user1.setDate_of_birth(tokens[4]);
                    user1.setPhone_number(tokens[5]);
                    user1.setInfected(tokens[6]);
                    if("yes".equalsIgnoreCase(tokens[6])){
                        user1.setDate_diagnosis(tokens[7]);
                    }
                    else if("no".equalsIgnoreCase(tokens[6]))
                    {
                        user1.setDate_diagnosis(null);                 
                    }
                    
                    user.add(user1);
                }
            
            System.out.println("Your user information has been input into the system!");
            }
            catch(FileNotFoundException e){
                System.out.println(e);
            }
            //Collections.sort(user);
            
       return null;
        }
    /***
     * retrieve the user by its id. 
     * @param user_id
     * @return 
     */
    public static User getUserById(int user_id){
        User contact = new User();
        contact.setUser_id(user_id);
        int i = Collections.binarySearch(user, contact);
        if(i < 0){
            return null;
        }
        else{
        return user.get(i);
        }
    }
    /***
     * load the contact from the array 
     * list of users ids
     * @param user_id
     * @return 
     */
    public static ArrayList<User> loadContact(int user_id){
        loadFromFile();
       
        String line;
        String[] tokens;
        
        try(Scanner fileInput = new Scanner(new File(fileContact))){
            fileInput.nextLine();
                while(fileInput.hasNext()){
                line = fileInput.nextLine(); 
                Contact contact = new Contact();
                tokens = line.split(",");
                int rep = Integer.parseInt(tokens[0]);
                User reportingUser = getUserById(rep);
                contact.setReporting_user(reportingUser);                
                int cUse = Integer.parseInt(tokens[1]);
                User conUse = getUserById(cUse);
                contact.setContact_user(conUse);
                contact.setContact_start(tokens[2]);
                contact.setContact_end(tokens[3]);
                reportingUser.addContact(contact);
                //user.add(contact);                      
                }
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
            

        Collections.sort(user);
        return user;
    }
     private static void createBridgesGraph(ArrayList<User> users, int graphId)
    {
        // Initialize Bridges, set credentials, title, and description.
        System.out.print("Creating Bridges Graph...");
        Bridges bridges = new Bridges(graphId, "murphyZac", "771661806152");
        bridges.setTitle("Covid User Graph");
        bridges.setDescription("Showing Covid infections in a population.");

        // Create an adjacency-list-based graph
        GraphAdjListSimple<String> graph = new GraphAdjListSimple<>();
        System.out.print("creating verticies...");
        
        // Add users as vertexes in the graph.
        for (User user: users)
        {
            // The first argument is the id; the second argument is the label to display.
            // Currently BRIDGES ignores the label and displays the id.
            graph.addVertex(user.getUniqueName(), user.getUniqueName());
        }

        // Add contacts as edges in the graph between vertexes.
        System.out.print("creating edges...");
        Contact contact;
        
        for (User user: users)
        {
            if (!user.getContact().isEmpty())
            {
                contact = user.getContact().get(0);
                graph.addEdge(contact.getReporting_user().getUniqueName(), 
                    contact.getContact_user().getUniqueName(), 
                    // This third argument is the label for the edge, but BRIDGES appears to ignore it.
                    contact.getContact_start());
            }
            if (user.isInfected())
    {
    graph.getVertex(user.getUniqueName()).setColor("orange");
    }
        }
        
        // Pass the graph object to BRIDGES
        bridges.setDataStructure(graph);

        try
        {
            // Finaly, we call the visualize function
            bridges.visualize();
        }
        catch (IOException | RateLimitException exception)
        {
            System.out.println(exception);
        }

        System.out.println("done.");

}
//     public static ArrayList<User>patienZero(ArrayList<User> pZero){
//         DateDiagnosedComparator dateDiagCompare = new DateDiagnosedComparator();
//         Collections.sort(user, dateDiagCompare);
//         pZero = user;
//         User user1 = new User();
//         user.remove(user1.getUser_id());
//         user1.setIsPatientZero(true);
//         pZero.add(user1);
////         for(Contact contact : contacts){
////             if(contact.setContact_user(user1).isInfected()){
////                 contact.setIsPatientZero(true);
////                 user.remove(contact.setContact_user(user1));
////             }
////         }
//         return pZero;
//     }
}
