/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidtracing;

/**
 *
 * @author Zac
 */
public class Contact{
    private User reporting_user;
    private User contact_user;
    private String contact_start;
    private String contact_end;
    
    public Contact(){
        User reporting_user;
        User contact_user;
        contact_start = "";
        contact_end = "";
    }
    public Contact(User inReporting_user, User inContact_user, String inContact_start, String inContact_end){
        reporting_user = inReporting_user;
        contact_user = inContact_user;
        contact_start = inContact_start;
        contact_end = inContact_end;
    }

    public User getReporting_user() {
        return reporting_user;
    }

    public void setReporting_user(User reporting_user) {
        this.reporting_user = reporting_user;
    }

    public User getContact_user() {
        return contact_user;
    }

    public void setContact_user(User contact_user) {
        this.contact_user = contact_user;
    }

    public String getContact_start() {
        return contact_start;
    }

    public void setContact_start(String contact_start) {
        this.contact_start = contact_start;
    }

    public String getContact_end() {
        return contact_end;
    }

    public void setContact_end(String contact_end) {
        this.contact_end = contact_end;
    }
    
    @Override
    public String toString(){
        String contact = "reporting_user: " + this.reporting_user + " contact_user: " + this.contact_user
                + " contact_start: " + this.contact_start + " contact_end: " + this.contact_end;
        return contact;
    }
}
