/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidtracing;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Zac
 */
public class User implements Comparable<User>{
    private int user_id;
    private String first_name;
    private String last_name;
    private String gender;
    private String date_of_birth;
    private String phone_number;
    private String infected;
    public LocalDate date_diagnosis;
    public List<Contact> contacts;
    private boolean isPatientZero;
    
    public User(){
        user_id = 0;
        first_name = "";
        last_name = "";
        gender = "";
        date_of_birth = "";
        phone_number = ""; 
        infected = "";
        date_diagnosis = null;
        contacts = new ArrayList<>();
        isPatientZero = true;
    }
    public User(int inuser_id, String infirst_name,String inlast_name,String ingender, String indate_of_birth, 
            String inphone_number, String ininfected, LocalDate indate_diagnosis, List<Contact> inContact, boolean inIsPatientZero){
        user_id = inuser_id;
        first_name = infirst_name;
        last_name = inlast_name;
        gender = ingender;
        date_of_birth = indate_of_birth;
        phone_number = inphone_number; 
        infected = ininfected;
        date_diagnosis = indate_diagnosis;
        contacts = inContact;
        isPatientZero = inIsPatientZero;
    }

    public List<Contact> addContact(Contact con){
        if (con == null ){
            System.out.println(" ");
        }
        else{
            contacts.add(con);
        }
        return contacts;
    }
    public List<Contact> getContact() {
        return contacts;
    }

    public void setContact(List<Contact> contact) {
        this.contacts = contact;
    }

    public boolean isIsPatientZero() {
        return isPatientZero;
    }

    public void setIsPatientZero(boolean isPatientZero) {
        this.isPatientZero = isPatientZero;
    }
  
     
    
    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int inuser_id) {
        this.user_id = inuser_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String infirst_name) {
        this.first_name = infirst_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String inlast_name) {
        this.last_name = inlast_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String ingender) {
        this.gender = ingender;
    }

    public String getDate_of_birth() {
        return date_of_birth;
    }

    public void setDate_of_birth(String indate_of_birth) {
        this.date_of_birth = indate_of_birth;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String inphone_number) {
        this.phone_number = inphone_number;
    }

    public String getInfected() {
        return infected;
    }

    public void setInfected(String ininfected) {
        this.infected = ininfected;
    }

    public LocalDate getDate_diagnosis() {
        return date_diagnosis;
    }

    public void setDate_diagnosis(String indate_diagnosis) {
        //this.date_diagnosis = indate_diagnosis;
        if(indate_diagnosis == null){
            date_diagnosis = null;
                    //LocalDate.parse(indate_diagnosis);
        }
        else if("".equalsIgnoreCase(indate_diagnosis)){
            date_diagnosis = null;
                    //
        }
        else{
            date_diagnosis = LocalDate.parse(indate_diagnosis);
        }

    }
    public boolean isInfected(){
        boolean d = true;
        if("yes".equalsIgnoreCase(infected)){
            d = true;
        }
        else{
            d = false;
        }
        return d;
    }
    //make it so the data is output in a string rather than comp language 
    @Override
    public String toString(){
        String user = "user_id: " + this.user_id + ", first_name: " + this.first_name + ", last_name: " + this.last_name + ", gender: "  
        + this.gender + ", date_of_birth: " + this.date_of_birth + ", phone_number: " + this.phone_number + ", infected: " 
        + this.infected + ", date_diagnosis: " + this.date_diagnosis + "\n" + this.contacts + " contact: ";  
        return user;
    }

    public String getUniqueName(){
        String user = "user_id: " + this.user_id + ", first_name: " + this.first_name + ", last_name: " + this.last_name;
        return user;
    }
    //compare user id to other user id to make sure it isnt repeating 
    @Override
    public int compareTo(User o) {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        int value = 0;
        if (user_id > o.user_id){
            value = 1;
        }
        else if (user_id < o.user_id){
            value = -1;
        }
        return value ;
    }


}
